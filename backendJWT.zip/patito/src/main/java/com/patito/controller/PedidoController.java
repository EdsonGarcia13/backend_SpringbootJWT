package com.patito.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.patito.entities.Pedido;
import com.patito.entities.Producto;
import com.patito.repository.PedidoRepository;
import com.patito.repository.ProductoRepository;

@RestController
@RequestMapping("/api")
public class PedidoController {
    @Autowired
    private PedidoRepository pedidoRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @GetMapping("/producto/{hawa}")
    public ResponseEntity<Producto> getProductoByHawa(@PathVariable Long hawa) {
        Optional<Producto> producto = productoRepository.findById(hawa);
        if (producto.isPresent()) {
            return ResponseEntity.ok(producto.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/pedido")
    public ResponseEntity<Pedido> createPedido(@RequestBody Pedido pedido) {
        for (Producto producto : pedido.getProductos()) {
            Optional<Producto> productoOptional = productoRepository.findById(producto.getHawa());
            if (productoOptional.isPresent()) {
                Producto productoExistente = productoOptional.get();
                if (productoExistente.getExistencias() < producto.getExistencias()) {
                    return ResponseEntity.badRequest().build();
                }
                productoExistente.setExistencias(productoExistente.getExistencias() - producto.getExistencias());
                productoRepository.save(productoExistente);
            } else {
                return ResponseEntity.badRequest().build();
            }
        }
        pedidoRepository.save(pedido);
        return ResponseEntity.ok(pedido);
    }

    @GetMapping("/pedido")
    public ResponseEntity<List<Pedido>> getAllPedidos() {
        List<Pedido> pedidos = pedidoRepository.findAll();
        return ResponseEntity.ok(pedidos);
    }

    @GetMapping("/pedido/{id}")
    public ResponseEntity<Pedido> getPedidoById(@PathVariable Long id) {
        Optional<Pedido> pedido = pedidoRepository.findById(id);
        if (pedido.isPresent()) {
            return ResponseEntity.ok(pedido.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/pedido/{id}")
    public ResponseEntity<Pedido> updatePedidoEstatus(@PathVariable Long id, @RequestBody Pedido pedido) {
        Optional<Pedido> pedidoOptional = pedidoRepository.findById(id);
        if (pedidoOptional.isPresent()) {
            Pedido pedidoExistente = pedidoOptional.get();
            if (pedidoExistente.getEstatus().equals("pendiente") && !pedido.getEstatus().equals("pendiente")) {
                pedidoExistente.setEstatus(pedido.getEstatus());
                pedidoRepository.save(pedidoExistente);
                return ResponseEntity.ok(pedidoExistente);
            } else if (pedidoExistente.getEstatus().equals("pendiente") && pedido.getEstatus().equals("cancelado")) {
                Date fechaActual = new Date();
                long diffInMillies = Math.abs(fechaActual.getTime() - pedidoExistente.getFecha().getTime());
                long diff = TimeUnit.MINUTES.convert(diffInMillies, TimeUnit.MILLISECONDS);
                if (diff > 10) {
                    return ResponseEntity.badRequest().build();
                } else {
                    pedidoExistente.setEstatus(pedido.getEstatus());
                    pedidoRepository.save(pedidoExistente);
                    return ResponseEntity.ok(pedidoExistente);
                }
            } else {
                return ResponseEntity.badRequest().build();
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}